create
    definer = root@`%` function getAssignmentsGradedByTeacher(teacher_id int) returns int deterministic
BEGIN
    DECLARE graded_assignments INT;

    -- Count the number of assignments graded by the teacher (inactive assignments)
    SELECT COUNT(*)
    INTO graded_assignments
    FROM progress_assignment pa
             JOIN progress p ON pa.progress_id = p.id
             JOIN classroom c ON p.classroom_id = c.id
             JOIN teacher t ON c.teacher_id = t.id
    WHERE pa.status = 'inactive' AND c.teacher_id = teacher_id;

    RETURN graded_assignments;
END;

