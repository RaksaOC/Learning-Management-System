create
    definer = root@`%` procedure DeleteAssignment(IN p_assignment_id varchar(50))
BEGIN
    -- Update status to 'inactive' in the assignment table
    UPDATE assignment
    SET status = 'inactive'
    WHERE id = p_assignment_id;

    -- Delete from classroom_assignment table
    DELETE FROM classroom_assignment ca
    WHERE ca.assignment_id = p_assignment_id;

    -- Delete from progress_assignment table
    DELETE FROM progress_assignment pa
    WHERE pa.assignment_id = p_assignment_id;
END;

