create
    definer = root@`%` procedure EditTeacherDOB(IN teacher_id varchar(50), IN new_dob date)
BEGIN
    UPDATE teacher
    SET dob = new_dob
    WHERE id = teacher_id;
END;

