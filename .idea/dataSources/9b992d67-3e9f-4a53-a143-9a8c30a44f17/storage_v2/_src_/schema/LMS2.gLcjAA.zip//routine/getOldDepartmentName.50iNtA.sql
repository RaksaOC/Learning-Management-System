create
    definer = root@`%` function getOldDepartmentName(idToEdit varchar(255)) returns varchar(255) deterministic
BEGIN
    DECLARE department_name VARCHAR(255);

    SELECT name INTO department_name
    FROM department
    WHERE id = idToEdit;

    RETURN department_name;
END;

