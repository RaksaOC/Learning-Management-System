create definer = root@`%` view view_all_courses as
select `LMS2`.`course`.`id`          AS `id`,
       `LMS2`.`course`.`name`        AS `name`,
       `LMS2`.`course`.`credit`      AS `credit`,
       `LMS2`.`course`.`level`       AS `level`,
       `LMS2`.`course`.`description` AS `description`,
       `LMS2`.`course`.`status`      AS `status`
from `LMS2`.`course`;

