create
    definer = root@`%` function getOldLastName(idToEdit varchar(255)) returns varchar(255) deterministic
BEGIN
    DECLARE last_name VARCHAR(255);

    SELECT last_name INTO last_name
    FROM admin
    WHERE id = idToEdit;

    RETURN last_name;
END;

