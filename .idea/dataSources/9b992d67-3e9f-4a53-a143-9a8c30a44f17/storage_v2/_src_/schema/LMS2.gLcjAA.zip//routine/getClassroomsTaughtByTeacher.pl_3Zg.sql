create
    definer = root@`%` function getClassroomsTaughtByTeacher(teacher_id int) returns int deterministic
BEGIN
    DECLARE classrooms_taught INT;

    -- Count the number of classrooms taught by the teacher
    SELECT COUNT(*)
    INTO classrooms_taught
    FROM classroom
    WHERE classroom.teacher_id = teacher_id;

    RETURN classrooms_taught;
END;

