create
    definer = root@`%` function getOldPhone(idToEdit varchar(255)) returns varchar(50) deterministic
BEGIN
    DECLARE phone_number VARCHAR(50);

    SELECT phone_number INTO phone_number
    FROM admin
    WHERE id = idToEdit;

    RETURN phone_number;
END;

