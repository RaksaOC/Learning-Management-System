create
    definer = root@`%` procedure EditSpecializationId(IN old_specialization_id varchar(50),
                                                      IN new_specialization_id varchar(50))
BEGIN
    UPDATE specialization
    SET id = new_specialization_id
    WHERE id = old_specialization_id;
END;

