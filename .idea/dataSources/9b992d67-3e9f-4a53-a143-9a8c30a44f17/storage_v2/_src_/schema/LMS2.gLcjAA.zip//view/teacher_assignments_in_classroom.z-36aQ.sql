create definer = root@`%` view teacher_assignments_in_classroom as
select concat(`a`.`id`, ' - ', `a`.`title`) AS `assignment_id_name`
from (((`LMS2`.`progress_assignment` `pa` join `LMS2`.`progress` `p`
        on ((`pa`.`progress_id` = `p`.`id`))) join `LMS2`.`assignment` `a`
       on ((`pa`.`assignment_id` = `a`.`id`))) join `LMS2`.`classroom` `c` on ((`p`.`classroom_id` = `c`.`id`)))
where ((`p`.`classroom_id` = 'classroom_id') and (`c`.`teacher_id` = 'teacher_id'));

