create definer = root@`%` view view_all_student_groups as
select `LMS2`.`student_group`.`id`                AS `id`,
       `LMS2`.`student_group`.`generation_id`     AS `generation_id`,
       `LMS2`.`student_group`.`specialization_id` AS `specialization_id`,
       `LMS2`.`student_group`.`status`            AS `status`
from `LMS2`.`student_group`;

