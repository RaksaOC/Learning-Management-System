create
    definer = root@`%` procedure EditTeacherGender(IN teacher_id varchar(50), IN new_gender varchar(10))
BEGIN
    UPDATE teacher
    SET gender = new_gender
    WHERE id = teacher_id;
END;

