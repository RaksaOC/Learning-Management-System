create
    definer = root@`%` procedure EditSpecializationName(IN specialization_id varchar(50),
                                                        IN new_specialization_name varchar(255))
BEGIN
    UPDATE specialization
    SET name = new_specialization_name
    WHERE id = specialization_id;
END;

