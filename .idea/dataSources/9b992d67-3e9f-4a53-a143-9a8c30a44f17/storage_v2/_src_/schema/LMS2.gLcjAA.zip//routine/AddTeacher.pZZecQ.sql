create
    definer = root@`%` procedure AddTeacher(IN p_id varchar(10), IN p_first_name varchar(255),
                                            IN p_last_name varchar(255), IN p_gender varchar(50), IN p_dob date,
                                            IN p_phone_number varchar(20), IN p_email varchar(255),
                                            IN p_status varchar(50), IN p_created_at timestamp,
                                            IN p_last_login timestamp, IN p_password varchar(255))
BEGIN
    INSERT INTO teacher (id, first_name, last_name, gender, dob, phone_number, email, status, created_at, last_login, password)
    VALUES (p_id, p_first_name, p_last_name, p_gender, p_dob, p_phone_number, p_email, p_status,
            p_created_at, p_last_login, p_password);
END;

