create
    definer = root@`%` function getOldStudentGuardianFirstName(idToEdit varchar(255)) returns varchar(255) deterministic
BEGIN
    DECLARE result VARCHAR(255);
    SELECT guardian_first_name INTO result FROM student WHERE id = idToEdit;
    RETURN result;
END;

