create
    definer = root@`%` procedure EditAdminPhone(IN admin_id varchar(50), IN new_phone_number varchar(20))
BEGIN
    UPDATE admin
    SET phone_number = new_phone_number
    WHERE id = admin_id;
END;

