create
    definer = root@`%` function isTeacherEmailTaken(f_email varchar(255)) returns tinyint(1) deterministic
BEGIN
    DECLARE email_count INT;

    SELECT COUNT(*)
    INTO email_count
    FROM teacher
    WHERE f_email = email;

    RETURN email_count > 0;
END;

