create
    definer = root@`%` function getOldDepartmentId(idToEdit varchar(255)) returns varchar(255) deterministic
BEGIN
    DECLARE department_id VARCHAR(255);

    SELECT id INTO department_id
    FROM department
    WHERE id = idToEdit;

    RETURN department_id;
END;

