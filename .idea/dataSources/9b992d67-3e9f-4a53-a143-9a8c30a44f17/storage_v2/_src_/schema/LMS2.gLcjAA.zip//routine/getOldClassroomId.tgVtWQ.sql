create
    definer = root@`%` function getOldClassroomId(idToEdit varchar(255)) returns varchar(255) deterministic
BEGIN
    DECLARE classroom_id VARCHAR(255);

    SELECT id INTO classroom_id
    FROM classroom
    WHERE id = idToEdit;

    RETURN classroom_id;
END;

