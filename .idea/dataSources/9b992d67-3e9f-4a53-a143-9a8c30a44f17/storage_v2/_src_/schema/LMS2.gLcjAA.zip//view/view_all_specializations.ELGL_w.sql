create definer = root@`%` view view_all_specializations as
select `LMS2`.`specialization`.`id`            AS `id`,
       `LMS2`.`specialization`.`department_id` AS `department_id`,
       `LMS2`.`specialization`.`name`          AS `name`,
       `LMS2`.`specialization`.`status`        AS `status`
from `LMS2`.`specialization`;

