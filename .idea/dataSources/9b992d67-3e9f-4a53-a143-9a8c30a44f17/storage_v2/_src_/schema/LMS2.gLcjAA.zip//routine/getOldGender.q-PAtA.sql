create
    definer = root@`%` function getOldGender(idToEdit varchar(255)) returns varchar(50) deterministic
BEGIN
    DECLARE gender VARCHAR(50);

    SELECT gender INTO gender
    FROM admin
    WHERE id = idToEdit;

    RETURN gender;
END;

