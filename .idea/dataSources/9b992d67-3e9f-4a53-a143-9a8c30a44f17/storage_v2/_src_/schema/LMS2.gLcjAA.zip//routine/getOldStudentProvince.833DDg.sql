create
    definer = root@`%` function getOldStudentProvince(idToEdit varchar(255)) returns varchar(255) deterministic
BEGIN
    DECLARE result VARCHAR(255);
    SELECT province INTO result FROM student WHERE id = idToEdit;
    RETURN result;
END;

