create definer = root@`%` view view_active_classrooms as
select `LMS2`.`classroom`.`id`         AS `id`,
       `LMS2`.`classroom`.`teacher_id` AS `teacher_id`,
       `LMS2`.`classroom`.`course_id`  AS `course_id`,
       `LMS2`.`classroom`.`group_id`   AS `group_id`
from `LMS2`.`classroom`
where (`LMS2`.`classroom`.`status` = 'active')
order by `LMS2`.`classroom`.`id`;

