create
    definer = root@`%` procedure EditStudentSpecialization(IN student_id varchar(50), IN new_specialization_id varchar(50))
BEGIN
    UPDATE student
    SET specialization_id = new_specialization_id
    WHERE id = student_id;
END;

