create
    definer = root@`%` procedure EditTeacherPassword(IN teacher_id varchar(50), IN new_password varchar(255))
BEGIN
    UPDATE teacher
    SET password = new_password
    WHERE id = teacher_id;
END;

