create
    definer = root@`%` procedure AddCourse(IN p_id varchar(50), IN p_name varchar(255), IN p_credit varchar(50),
                                           IN p_level varchar(50), IN p_description text, IN p_status varchar(50))
BEGIN
    INSERT INTO course (id, name, credit, level, description, status)
    VALUES (p_id, p_name, p_credit, p_level, p_description, p_status);
END;

