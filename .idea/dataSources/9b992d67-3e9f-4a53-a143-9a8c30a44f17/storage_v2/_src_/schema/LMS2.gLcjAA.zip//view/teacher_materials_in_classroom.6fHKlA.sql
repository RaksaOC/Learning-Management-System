create definer = root@`%` view teacher_materials_in_classroom as
select concat(`m`.`id`, ' - ', `m`.`title`) AS `material_id_name`
from (((`LMS2`.`progress_material` `pm` join `LMS2`.`progress` `p`
        on ((`pm`.`progress_id` = `p`.`id`))) join `LMS2`.`material` `m`
       on ((`pm`.`material_id` = `m`.`id`))) join `LMS2`.`classroom` `c` on ((`p`.`classroom_id` = `c`.`id`)))
where ((`p`.`classroom_id` = 'class_id') and (`c`.`teacher_id` = 'teacher_id'));

