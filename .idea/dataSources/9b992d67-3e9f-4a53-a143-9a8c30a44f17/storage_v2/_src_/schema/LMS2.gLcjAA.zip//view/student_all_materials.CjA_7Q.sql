create definer = root@`%` view student_all_materials as
select concat(`m`.`id`, ' - ', `m`.`title`) AS `material_id_name`, `p`.`classroom_id` AS `class_id`
from ((`LMS2`.`progress_material` `pm` join `LMS2`.`progress` `p`
       on ((`pm`.`progress_id` = `p`.`id`))) join `LMS2`.`material` `m` on ((`pm`.`material_id` = `m`.`id`)))
where (`p`.`student_id` = 'student_id');

