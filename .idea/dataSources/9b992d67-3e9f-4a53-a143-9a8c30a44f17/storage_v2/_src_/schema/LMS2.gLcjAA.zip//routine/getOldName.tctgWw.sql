create
    definer = root@`%` function getOldName(idToEdit varchar(255)) returns varchar(255) deterministic
BEGIN
    DECLARE full_name VARCHAR(255);

    SELECT CONCAT(first_name, ' ', last_name) INTO full_name
    FROM admin
    WHERE id = idToEdit;

    RETURN full_name;
END;

