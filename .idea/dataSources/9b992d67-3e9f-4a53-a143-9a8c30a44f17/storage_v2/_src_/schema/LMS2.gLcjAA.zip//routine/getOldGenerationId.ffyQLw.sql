create
    definer = root@`%` function getOldGenerationId(idToEdit varchar(255)) returns varchar(255) deterministic
BEGIN
    DECLARE generation_id VARCHAR(255);

    SELECT id INTO generation_id
    FROM generation
    WHERE id = idToEdit;

    RETURN generation_id;
END;

