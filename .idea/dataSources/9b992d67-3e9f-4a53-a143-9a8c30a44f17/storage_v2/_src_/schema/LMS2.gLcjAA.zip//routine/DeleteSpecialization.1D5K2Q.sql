create
    definer = root@`%` procedure DeleteSpecialization(IN p_id varchar(50))
BEGIN
    UPDATE specialization
    SET status = 'inactive'
    WHERE id = p_id;
END;

