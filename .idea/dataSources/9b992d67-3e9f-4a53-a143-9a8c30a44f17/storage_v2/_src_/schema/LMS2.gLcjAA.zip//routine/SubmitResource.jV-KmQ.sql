create
    definer = root@`%` procedure SubmitResource(IN p_student_id varchar(50), IN p_material_id varchar(50))
BEGIN
    UPDATE progress_material pr
        JOIN progress p ON pr.progress_id = p.id
    SET pr.status = 'inactive'
    WHERE p.student_id = p_student_id AND pr.material_id = p_material_id;
END;

