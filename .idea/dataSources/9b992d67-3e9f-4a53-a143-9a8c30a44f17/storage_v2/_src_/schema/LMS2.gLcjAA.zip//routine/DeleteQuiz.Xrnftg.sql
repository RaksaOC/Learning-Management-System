create
    definer = root@`%` procedure DeleteQuiz(IN p_quiz_id varchar(50))
BEGIN
    -- Delete from classroom_quiz (removing the quiz from classrooms)
    DELETE FROM classroom_quiz cq
    WHERE cq.quiz_id = p_quiz_id;

    -- Delete from progress_quiz (removing the quiz from student progress)
    DELETE FROM progress_quiz pq
    WHERE pq.quiz_id = p_quiz_id;

    -- Set the quiz status to inactive
    UPDATE quiz
    SET status = 'inactive'
    WHERE id = p_quiz_id;

    -- Delete associated questions and choices
    DELETE FROM choice
    WHERE question_id IN (SELECT id FROM question q WHERE q.id = p_quiz_id);

    DELETE FROM question q
    WHERE q.quiz_id = p_quiz_id;
END;

