create definer = root@`%` view view_all_departments as
select `LMS2`.`department`.`id`     AS `id`,
       `LMS2`.`department`.`name`   AS `name`,
       `LMS2`.`department`.`status` AS `status`
from `LMS2`.`department`;

