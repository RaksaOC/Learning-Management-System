create
    definer = root@`%` procedure AddAdmin(IN p_id varchar(10), IN p_first_name varchar(255),
                                          IN p_last_name varchar(255), IN p_created_at timestamp,
                                          IN p_password varchar(255), IN p_phone_number varchar(20),
                                          IN p_gender varchar(10), IN p_dob date, IN p_email varchar(255),
                                          IN p_status varchar(20))
BEGIN
    INSERT INTO admin (id, first_name, last_name, created_at, last_login, password, phone_number, gender, dob, email, status)
    VALUES (p_id, p_first_name, p_last_name, p_created_at, NULL, p_password, p_phone_number, p_gender, p_dob, p_email, p_status);
END;

