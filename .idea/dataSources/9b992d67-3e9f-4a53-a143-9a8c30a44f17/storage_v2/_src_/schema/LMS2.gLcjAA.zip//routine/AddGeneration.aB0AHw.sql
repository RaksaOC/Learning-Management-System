create
    definer = root@`%` procedure AddGeneration(IN p_id varchar(50), IN p_name varchar(255), IN p_status varchar(50))
BEGIN
    INSERT INTO generation (id, name, status)
    VALUES (p_id, p_name, p_status);
END;

