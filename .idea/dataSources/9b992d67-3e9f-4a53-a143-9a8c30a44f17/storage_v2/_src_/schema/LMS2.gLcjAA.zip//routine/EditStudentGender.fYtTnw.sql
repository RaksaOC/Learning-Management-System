create
    definer = root@`%` procedure EditStudentGender(IN student_id varchar(50), IN new_gender varchar(10))
BEGIN
    UPDATE student
    SET gender = new_gender
    WHERE id = student_id;
END;

