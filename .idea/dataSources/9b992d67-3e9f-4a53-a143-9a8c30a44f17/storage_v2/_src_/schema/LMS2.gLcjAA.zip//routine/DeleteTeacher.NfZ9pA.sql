create
    definer = root@`%` procedure DeleteTeacher(IN p_id varchar(50))
BEGIN
    UPDATE teacher
    SET status = 'inactive'
    WHERE id = p_id;
END;

