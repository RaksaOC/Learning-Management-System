create
    definer = root@`%` function getOldCourseId(idToEdit varchar(255)) returns varchar(255) deterministic
BEGIN
    DECLARE course_id VARCHAR(255);

    SELECT id INTO course_id
    FROM course
    WHERE id = idToEdit;

    RETURN course_id;
END;

