create
    definer = root@`%` procedure SubmitAssignment(IN p_student_id varchar(50), IN p_assignment_id varchar(50),
                                                  IN p_sub_attachment varchar(255))
BEGIN
    UPDATE progress_assignment pa
        JOIN progress p ON pa.progress_id = p.id
    SET pa.sub_attachment = p_sub_attachment
    WHERE p.student_id = p_student_id AND pa.assignment_id = p_assignment_id;
END;

