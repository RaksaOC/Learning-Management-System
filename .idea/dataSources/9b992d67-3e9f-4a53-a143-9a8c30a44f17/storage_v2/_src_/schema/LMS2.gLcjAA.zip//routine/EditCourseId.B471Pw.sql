create
    definer = root@`%` procedure EditCourseId(IN old_course_id varchar(50), IN new_course_id varchar(50))
BEGIN
    UPDATE course
    SET id = new_course_id
    WHERE id = old_course_id;
END;

