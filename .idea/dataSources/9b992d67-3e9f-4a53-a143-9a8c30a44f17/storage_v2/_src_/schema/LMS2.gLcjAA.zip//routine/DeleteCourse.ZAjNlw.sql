create
    definer = root@`%` procedure DeleteCourse(IN p_id varchar(50))
BEGIN
    UPDATE course
    SET status = 'inactive'
    WHERE id = p_id;
END;

