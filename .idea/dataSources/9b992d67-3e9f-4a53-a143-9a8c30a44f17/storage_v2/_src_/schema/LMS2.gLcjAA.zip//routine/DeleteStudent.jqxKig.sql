create
    definer = root@`%` procedure DeleteStudent(IN p_id varchar(50))
BEGIN
    UPDATE student
    SET status = 'inactive'
    WHERE id = p_id;
END;

