create definer = root@`%` view view_all_students as
select `LMS2`.`student`.`id`                    AS `id`,
       `LMS2`.`student`.`first_name`            AS `first_name`,
       `LMS2`.`student`.`last_name`             AS `last_name`,
       `LMS2`.`student`.`gender`                AS `gender`,
       `LMS2`.`student`.`dob`                   AS `dob`,
       `LMS2`.`student`.`phone_number`          AS `phone_number`,
       `LMS2`.`student`.`email`                 AS `email`,
       `LMS2`.`student`.`password`              AS `password`,
       `LMS2`.`student`.`commune`               AS `commune`,
       `LMS2`.`student`.`district`              AS `district`,
       `LMS2`.`student`.`province`              AS `province`,
       `LMS2`.`student`.`status`                AS `status`,
       `LMS2`.`student`.`created_at`            AS `created_at`,
       `LMS2`.`student`.`last_login`            AS `last_login`,
       `LMS2`.`student`.`department_id`         AS `department_id`,
       `LMS2`.`student`.`specialization_id`     AS `specialization_id`,
       `LMS2`.`student`.`generation_id`         AS `generation_id`,
       `LMS2`.`student`.`guardian_first_name`   AS `guardian_first_name`,
       `LMS2`.`student`.`guardian_last_name`    AS `guardian_last_name`,
       `LMS2`.`student`.`guardian_phone_number` AS `guardian_phone_number`,
       `LMS2`.`student`.`guardian_gender`       AS `guardian_gender`
from `LMS2`.`student`;

