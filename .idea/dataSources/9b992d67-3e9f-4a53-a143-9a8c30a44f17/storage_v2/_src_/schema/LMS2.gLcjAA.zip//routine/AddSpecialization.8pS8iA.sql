create
    definer = root@`%` procedure AddSpecialization(IN p_specialization_id varchar(50), IN p_department_id varchar(50),
                                                   IN p_specialization_name varchar(255),
                                                   IN p_specialization_status varchar(50))
BEGIN
    INSERT INTO specialization (id, department_id, name, status)
    VALUES (p_specialization_id, p_department_id, p_specialization_name, p_specialization_status);
END;

