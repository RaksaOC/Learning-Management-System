create definer = root@`%` view view_student_group_ids as
select `LMS2`.`student_group`.`id` AS `id`
from `LMS2`.`student_group`;

