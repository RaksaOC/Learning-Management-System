create
    definer = root@`%` procedure EditAssignment(IN p_new_title varchar(255), IN p_new_description text,
                                                IN p_new_deadline date, IN p_new_ref_attachment varchar(255),
                                                IN p_assignment_id varchar(50))
BEGIN
    -- Update the assignment table with the new values
    UPDATE assignment
    SET title = p_new_title, description = p_new_description, deadline = p_new_deadline, ref_attachment = p_new_ref_attachment
    WHERE id = p_assignment_id;
END;

