create
    definer = root@`%` function getOldStudentGroupId(idToEdit varchar(255)) returns varchar(255) deterministic
BEGIN
    DECLARE student_group_id VARCHAR(255);

    SELECT id INTO student_group_id
    FROM student_group
    WHERE id = idToEdit;

    RETURN student_group_id;
END;

