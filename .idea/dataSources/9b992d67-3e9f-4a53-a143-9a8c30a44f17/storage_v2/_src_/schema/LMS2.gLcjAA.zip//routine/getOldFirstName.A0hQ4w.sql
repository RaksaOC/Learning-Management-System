create
    definer = root@`%` function getOldFirstName(idToEdit varchar(255)) returns varchar(255) deterministic
BEGIN
    DECLARE first_name VARCHAR(255);

    SELECT first_name INTO first_name
    FROM admin
    WHERE id = idToEdit;

    RETURN first_name;
END;

