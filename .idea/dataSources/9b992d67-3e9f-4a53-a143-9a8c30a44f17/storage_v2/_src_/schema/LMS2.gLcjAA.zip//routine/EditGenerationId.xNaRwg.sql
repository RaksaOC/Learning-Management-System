create
    definer = root@`%` procedure EditGenerationId(IN old_generation_id varchar(50), IN new_generation_id varchar(50))
BEGIN
    UPDATE generation
    SET id = new_generation_id
    WHERE id = old_generation_id;
END;

