create
    definer = root@`%` procedure EditStudentPassword(IN student_id varchar(50), IN new_password varchar(255))
BEGIN
    UPDATE student
    SET password = new_password
    WHERE id = student_id;
END;

