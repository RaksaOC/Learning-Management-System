create definer = root@`%` view student_materials_in_classroom as
select concat(`m`.`id`, ' - ', `m`.`title`) AS `material_id_name`
from ((`LMS2`.`progress_material` `pm` join `LMS2`.`progress` `p`
       on ((`pm`.`progress_id` = `p`.`id`))) join `LMS2`.`material` `m` on ((`pm`.`material_id` = `m`.`id`)))
where ((`p`.`classroom_id` = 'classroom_id') and (`p`.`student_id` = 'student_id'));

