create definer = root@`%` view teacher_assigned_classrooms as
select `LMS2`.`classroom`.`id` AS `id`
from `LMS2`.`classroom`
where (`LMS2`.`classroom`.`teacher_id` = 'teacher_id');

