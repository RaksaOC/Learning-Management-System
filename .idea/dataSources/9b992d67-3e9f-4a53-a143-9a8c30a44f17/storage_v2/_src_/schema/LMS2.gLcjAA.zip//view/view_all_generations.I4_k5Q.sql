create definer = root@`%` view view_all_generations as
select `LMS2`.`generation`.`id`     AS `id`,
       `LMS2`.`generation`.`name`   AS `name`,
       `LMS2`.`generation`.`status` AS `status`
from `LMS2`.`generation`;

