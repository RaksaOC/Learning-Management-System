create
    definer = root@`%` function getAssignmentsCreatedByTeacher(teacher_id int) returns int deterministic
BEGIN
    DECLARE created_assignments INT;

    -- Count the number of assignments created by the teacher
    SELECT COUNT(*)
    INTO created_assignments
    FROM classroom_assignment ca
             JOIN classroom c ON ca.class_id = c.id
    WHERE c.teacher_id = teacher_id;

    RETURN created_assignments;
END;

