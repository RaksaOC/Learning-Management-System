create
    definer = root@`%` function getCompletedQuizzes(student_id int) returns int deterministic
BEGIN
    DECLARE completed_quizzes INT;

    -- Count the number of quizzes that the student has completed (inactive status)
    SELECT COUNT(*)
    INTO completed_quizzes
    FROM quiz a
             JOIN progress_quiz pq ON a.id = pq.quiz_id AND pq.status = 'inactive'
             JOIN progress p ON pq.progress_id = p.id
    WHERE p.student_id = student_id;

    RETURN completed_quizzes;
END;

