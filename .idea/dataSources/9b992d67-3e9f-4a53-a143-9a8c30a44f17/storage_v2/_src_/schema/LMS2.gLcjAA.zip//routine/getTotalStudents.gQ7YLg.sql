create
    definer = root@`%` function getTotalStudents() returns int deterministic
BEGIN
    DECLARE student_count INT;

    -- Count the total number of students
    SELECT COUNT(*)
    INTO student_count
    FROM student;

    RETURN student_count;
END;

