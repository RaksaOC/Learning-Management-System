create definer = root@`%` view student_completed_classrooms as
select concat(`p`.`classroom_id`, ' - ', `c`.`name`) AS `classroom_name`
from ((`LMS2`.`progress` `p` join `LMS2`.`classroom` `cl`
       on ((`cl`.`id` = `p`.`classroom_id`))) join `LMS2`.`course` `c` on ((`cl`.`course_id` = `c`.`id`)))
where (`p`.`student_id` = 'student_id');

