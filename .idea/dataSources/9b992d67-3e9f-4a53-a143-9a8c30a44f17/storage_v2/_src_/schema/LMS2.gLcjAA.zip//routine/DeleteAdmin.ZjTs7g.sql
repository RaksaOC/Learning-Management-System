create
    definer = root@`%` procedure DeleteAdmin(IN p_id varchar(10))
BEGIN
    UPDATE admin SET status = 'inactive' WHERE id = p_id;
END;

