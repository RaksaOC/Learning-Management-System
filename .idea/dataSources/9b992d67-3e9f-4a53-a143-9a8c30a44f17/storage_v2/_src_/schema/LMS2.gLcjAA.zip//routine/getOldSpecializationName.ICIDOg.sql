create
    definer = root@`%` function getOldSpecializationName(idToEdit varchar(255)) returns varchar(255) deterministic
BEGIN
    DECLARE specialization_name VARCHAR(255);

    SELECT name INTO specialization_name
    FROM specialization
    WHERE id = idToEdit;

    RETURN specialization_name;
END;

