create
    definer = root@`%` procedure EditStudentDepartment(IN student_id varchar(50), IN new_department_id varchar(50))
BEGIN
    UPDATE student
    SET department_id = new_department_id
    WHERE id = student_id;
END;

