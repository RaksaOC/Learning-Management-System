create definer = root@`%` view student_quizzes_in_classroom as
select concat(`q`.`id`, ' - ', `q`.`title`) AS `quiz_id_name`
from ((`LMS2`.`progress_quiz` `pq` join `LMS2`.`progress` `p`
       on ((`pq`.`progress_id` = `p`.`id`))) join `LMS2`.`quiz` `q` on ((`pq`.`quiz_id` = `q`.`id`)))
where ((`p`.`classroom_id` = 'classroom_id') and (`p`.`student_id` = 'student_id'));

