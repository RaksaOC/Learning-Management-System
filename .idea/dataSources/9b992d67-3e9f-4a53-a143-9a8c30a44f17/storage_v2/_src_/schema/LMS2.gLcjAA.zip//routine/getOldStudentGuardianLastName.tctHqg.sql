create
    definer = root@`%` function getOldStudentGuardianLastName(idToEdit varchar(255)) returns varchar(255) deterministic
BEGIN
    DECLARE result VARCHAR(255);
    SELECT guardian_last_name INTO result FROM student WHERE id = idToEdit;
    RETURN result;
END;

