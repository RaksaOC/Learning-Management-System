create
    definer = root@`%` procedure EditDepartmentId(IN old_department_id varchar(50), IN new_department_id varchar(50))
BEGIN
    UPDATE department
    SET id = new_department_id
    WHERE id = old_department_id;
END;

