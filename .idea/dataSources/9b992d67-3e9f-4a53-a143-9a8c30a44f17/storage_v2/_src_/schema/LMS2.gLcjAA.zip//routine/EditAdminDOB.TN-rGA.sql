create
    definer = root@`%` procedure EditAdminDOB(IN admin_id varchar(50), IN new_dob date)
BEGIN
    UPDATE admin
    SET dob = new_dob
    WHERE id = admin_id;
END;

