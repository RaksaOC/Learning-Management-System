create
    definer = root@`%` function getCompletedAssignments(student_id int) returns int deterministic
BEGIN
    DECLARE completed_assignments INT;

    -- Count the number of assignments that the student has completed (inactive status)
    SELECT COUNT(*)
    INTO completed_assignments
    FROM assignment a
             JOIN progress_assignment pa ON a.id = pa.assignment_id AND pa.status = 'inactive'
             JOIN progress p ON pa.progress_id = p.id
    WHERE p.student_id = student_id;

    RETURN completed_assignments;
END;

