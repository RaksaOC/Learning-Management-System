create
    definer = root@`%` procedure EditTeacherEmail(IN teacher_id varchar(50), IN new_email varchar(255))
BEGIN
    UPDATE teacher
    SET email = new_email
    WHERE id = teacher_id;
END;

