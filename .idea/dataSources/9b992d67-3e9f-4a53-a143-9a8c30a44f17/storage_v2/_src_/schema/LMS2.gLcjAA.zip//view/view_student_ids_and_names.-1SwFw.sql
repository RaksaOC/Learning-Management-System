create definer = root@`%` view view_student_ids_and_names as
select `LMS2`.`student`.`id`                                                    AS `id`,
       concat(`LMS2`.`student`.`first_name`, ' ', `LMS2`.`student`.`last_name`) AS `name`
from `LMS2`.`student`;

