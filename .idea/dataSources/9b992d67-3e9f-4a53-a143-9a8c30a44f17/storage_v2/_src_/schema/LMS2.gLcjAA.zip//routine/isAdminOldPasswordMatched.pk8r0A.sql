create
    definer = root@`%` function isAdminOldPasswordMatched(idToEdit varchar(255), oldPassword varchar(255)) returns tinyint(1)
    deterministic
BEGIN
    DECLARE password VARCHAR(255);

    SELECT password INTO password
    FROM admin
    WHERE id = idToEdit;

    RETURN password = oldPassword;
END;

