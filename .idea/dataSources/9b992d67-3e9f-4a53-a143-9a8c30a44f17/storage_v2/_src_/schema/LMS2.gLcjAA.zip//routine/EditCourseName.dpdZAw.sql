create
    definer = root@`%` procedure EditCourseName(IN course_id varchar(50), IN new_course_name varchar(255))
BEGIN
    UPDATE course
    SET name = new_course_name
    WHERE id = course_id;
END;

