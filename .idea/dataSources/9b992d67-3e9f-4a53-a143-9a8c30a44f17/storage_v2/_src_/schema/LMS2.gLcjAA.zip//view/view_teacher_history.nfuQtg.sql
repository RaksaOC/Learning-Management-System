create definer = root@`%` view view_teacher_history as
select `LMS2`.`teacher_history`.`teacher_id`  AS `id`,
       `LMS2`.`teacher_history`.`time`        AS `time`,
       `LMS2`.`teacher_history`.`last_action` AS `last_action`
from `LMS2`.`teacher_history`
order by `LMS2`.`teacher_history`.`time`;

