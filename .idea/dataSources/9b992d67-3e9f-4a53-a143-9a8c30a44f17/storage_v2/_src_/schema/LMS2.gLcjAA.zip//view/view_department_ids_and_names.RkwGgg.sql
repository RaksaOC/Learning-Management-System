create definer = root@`%` view view_department_ids_and_names as
select `LMS2`.`department`.`id` AS `id`, `LMS2`.`department`.`name` AS `name`
from `LMS2`.`department`
order by `LMS2`.`department`.`name`;

