create
    definer = root@`%` procedure AddClassroom(IN p_id varchar(255), IN p_teacher_id varchar(255),
                                              IN p_course_id varchar(255), IN p_group_id varchar(255),
                                              IN p_status varchar(50))
BEGIN
    INSERT INTO classroom (id, teacher_id, course_id, group_id, status)
    VALUES (p_id, p_teacher_id, p_course_id, p_group_id, p_status);

    INSERT INTO progress (id, student_id, classroom_id)
    SELECT UUID(), s.id, p_id
    FROM student s
    WHERE s.group_id = p_group_id;
END;

