create
    definer = root@`%` procedure AddStudent(IN p_id varchar(10), IN p_first_name varchar(255),
                                            IN p_last_name varchar(255), IN p_gender varchar(50), IN p_dob date,
                                            IN p_phone_number varchar(20), IN p_email varchar(255),
                                            IN p_password varchar(255), IN p_commune varchar(255),
                                            IN p_district varchar(255), IN p_province varchar(255),
                                            IN p_status varchar(50), IN p_created_at timestamp,
                                            IN p_last_login timestamp, IN p_department_id varchar(50),
                                            IN p_specialization_id varchar(50), IN p_generation_id varchar(50),
                                            IN p_guardian_first_name varchar(255), IN p_guardian_last_name varchar(255),
                                            IN p_guardian_phone_number varchar(20), IN p_guardian_gender varchar(50))
BEGIN
    INSERT INTO student (
        id, first_name, last_name, gender, dob, phone_number, email, password, commune, district, province, status,
        created_at, last_login, department_id, specialization_id, generation_id,
        guardian_first_name, guardian_last_name, guardian_phone_number, guardian_gender
    )
    VALUES (
               p_id, p_first_name, p_last_name, p_gender, p_dob, p_phone_number, p_email, p_password, p_commune, p_district, p_province, p_status,
               p_created_at, p_last_login, p_department_id, p_specialization_id, p_generation_id,
               p_guardian_first_name, p_guardian_last_name, p_guardian_phone_number, p_guardian_gender
           );
END;

