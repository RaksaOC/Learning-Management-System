create
    definer = root@`%` procedure EditAdminName(IN admin_id varchar(50), IN new_first_name varchar(255),
                                               IN new_last_name varchar(255))
BEGIN
    UPDATE admin
    SET first_name = new_first_name,
        last_name  = new_last_name
    WHERE id = admin_id;
END;

