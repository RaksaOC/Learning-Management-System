create
    definer = root@`%` procedure EditQuiz(IN p_quiz_id varchar(50), IN p_quiz_title varchar(255),
                                          IN p_quiz_description text, IN p_status varchar(50),
                                          IN p_class_id varchar(50), IN p_quiz_data json)
BEGIN
    CALL DeleteQuiz(p_quiz_id);

    -- CALL AddQuiz(p_quiz_title, p_quiz_description, p_status, p_class_id, p_quiz_data); TODO: add add quiz procedure

END;

