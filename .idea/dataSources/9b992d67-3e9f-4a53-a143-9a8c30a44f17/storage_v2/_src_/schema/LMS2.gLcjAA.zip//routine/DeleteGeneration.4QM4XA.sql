create
    definer = root@`%` procedure DeleteGeneration(IN p_id varchar(50))
BEGIN
    UPDATE generation
    SET status = 'inactive'
    WHERE id = p_id;
END;

