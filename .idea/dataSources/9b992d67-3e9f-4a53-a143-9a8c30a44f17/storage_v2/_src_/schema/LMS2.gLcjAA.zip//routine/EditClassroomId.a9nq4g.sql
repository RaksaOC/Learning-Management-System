create
    definer = root@`%` procedure EditClassroomId(IN old_classroom_id varchar(50), IN new_classroom_id varchar(50))
BEGIN
    UPDATE classroom
    SET id = new_classroom_id
    WHERE id = old_classroom_id;
END;

