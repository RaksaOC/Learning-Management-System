create definer = root@`%` view teacher_quizzes_in_classroom as
select concat(`q`.`id`, ' - ', `q`.`title`) AS `quiz_id_name`
from (((`LMS2`.`progress_quiz` `pq` join `LMS2`.`progress` `p`
        on ((`pq`.`progress_id` = `p`.`id`))) join `LMS2`.`quiz` `q`
       on ((`pq`.`quiz_id` = `q`.`id`))) join `LMS2`.`classroom` `c` on ((`p`.`classroom_id` = `c`.`id`)))
where ((`p`.`classroom_id` = 'class_id') and (`c`.`teacher_id` = 'teacher_id'));

