create definer = root@`%` view view_student_history as
select `LMS2`.`student_history`.`student_id`  AS `id`,
       `LMS2`.`student_history`.`time`        AS `time`,
       `LMS2`.`student_history`.`last_action` AS `last_action`
from `LMS2`.`student_history`
order by `LMS2`.`student_history`.`time`;

