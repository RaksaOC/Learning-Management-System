create
    definer = root@`%` function getOldStudentGuardianPhone(idToEdit varchar(255)) returns varchar(255) deterministic
BEGIN
    DECLARE result VARCHAR(255);
    SELECT guardian_phone_number INTO result FROM student WHERE id = idToEdit;
    RETURN result;
END;

