create
    definer = root@`%` procedure EditAdminEmail(IN admin_id varchar(50), IN new_email varchar(255))
BEGIN
    UPDATE admin
    SET email = new_email
    WHERE id = admin_id;
END;

