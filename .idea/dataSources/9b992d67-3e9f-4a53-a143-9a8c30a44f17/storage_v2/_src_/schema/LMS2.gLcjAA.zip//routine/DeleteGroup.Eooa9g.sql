create
    definer = root@`%` procedure DeleteGroup(IN p_id varchar(50))
BEGIN
    UPDATE student_group
    SET status = 'inactive'
    WHERE id = p_id;
END;

