create
    definer = root@`%` function getOldCourseName(idToEdit varchar(255)) returns varchar(255) deterministic
BEGIN
    DECLARE course_name VARCHAR(255);

    SELECT name INTO course_name
    FROM course
    WHERE id = idToEdit;

    RETURN course_name;
END;

