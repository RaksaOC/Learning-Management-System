create
    definer = root@`%` procedure EditStudentDOB(IN student_id varchar(50), IN new_dob date)
BEGIN
    UPDATE student
    SET dob = new_dob
    WHERE id = student_id;
END;

