create
    definer = root@`%` function getOldEmail(idToEdit varchar(255)) returns varchar(255) deterministic
BEGIN
    DECLARE email VARCHAR(255);

    SELECT email INTO email
    FROM admin
    WHERE id = idToEdit;

    RETURN email;
END;

