create definer = root@`%` view view_teacher_ids_and_names as
select `LMS2`.`teacher`.`id`                                                    AS `id`,
       concat(`LMS2`.`teacher`.`first_name`, ' ', `LMS2`.`teacher`.`last_name`) AS `name`
from `LMS2`.`teacher`;

