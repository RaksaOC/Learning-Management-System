create definer = root@`%` view student_all_assignments as
select concat(`a`.`id`, ' - ', `a`.`title`) AS `assignment_id_name`, `p`.`classroom_id` AS `class_id`
from ((`LMS2`.`progress_assignment` `pa` join `LMS2`.`progress` `p`
       on ((`pa`.`progress_id` = `p`.`id`))) join `LMS2`.`assignment` `a` on ((`pa`.`assignment_id` = `a`.`id`)))
where (`p`.`student_id` = 'student_id');

