create
    definer = root@`%` function getOldStudentPhone(idToEdit varchar(255)) returns varchar(255) deterministic
BEGIN
    DECLARE result VARCHAR(255);
    SELECT phone_number INTO result FROM student WHERE id = idToEdit;
    RETURN result;
END;

