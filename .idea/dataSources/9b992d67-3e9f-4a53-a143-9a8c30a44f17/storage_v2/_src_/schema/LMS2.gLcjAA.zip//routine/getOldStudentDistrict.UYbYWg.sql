create
    definer = root@`%` function getOldStudentDistrict(idToEdit varchar(255)) returns varchar(255) deterministic
BEGIN
    DECLARE result VARCHAR(255);
    SELECT district INTO result FROM student WHERE id = idToEdit;
    RETURN result;
END;

