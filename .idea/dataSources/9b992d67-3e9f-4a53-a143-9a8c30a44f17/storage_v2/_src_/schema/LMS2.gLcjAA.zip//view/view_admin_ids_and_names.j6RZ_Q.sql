create definer = root@`%` view view_admin_ids_and_names as
select `LMS2`.`admin`.`id` AS `id`, concat(`LMS2`.`admin`.`first_name`, ' ', `LMS2`.`admin`.`last_name`) AS `name`
from `LMS2`.`admin`
order by concat(`LMS2`.`admin`.`first_name`, ' ', `LMS2`.`admin`.`last_name`);

