create
    definer = root@`%` function getOldSpecializationId(idToEdit varchar(255)) returns varchar(255) deterministic
BEGIN
    DECLARE specialization_id VARCHAR(255);

    SELECT id INTO specialization_id
    FROM specialization
    WHERE id = idToEdit;

    RETURN specialization_id;
END;

