create
    definer = root@`%` procedure AddGroup(IN p_group_id varchar(50), IN p_generation_id varchar(50),
                                          IN p_specialization_id varchar(50), IN p_group_status varchar(50))
BEGIN
    INSERT INTO student_group (id, generation_id, specialization_id, status)
    VALUES (p_group_id, p_generation_id, p_specialization_id, p_group_status);
END;

