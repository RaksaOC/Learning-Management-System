create definer = root@`%` view view_specialization_ids_and_names as
select `LMS2`.`specialization`.`id` AS `id`, `LMS2`.`specialization`.`name` AS `name`
from `LMS2`.`specialization`;

