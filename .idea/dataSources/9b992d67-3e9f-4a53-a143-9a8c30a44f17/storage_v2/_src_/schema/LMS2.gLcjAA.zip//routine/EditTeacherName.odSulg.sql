create
    definer = root@`%` procedure EditTeacherName(IN teacher_id varchar(50), IN new_first_name varchar(255),
                                                 IN new_last_name varchar(255))
BEGIN
    UPDATE teacher
    SET first_name = new_first_name,
        last_name  = new_last_name
    WHERE id = teacher_id;
END;

