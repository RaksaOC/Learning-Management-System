create definer = root@`%` view student_assignments_in_classroom as
select concat(`a`.`id`, ' - ', `a`.`title`) AS `assignment_id_name`
from ((`LMS2`.`progress_assignment` `pa` join `LMS2`.`progress` `p`
       on ((`pa`.`progress_id` = `p`.`id`))) join `LMS2`.`assignment` `a` on ((`pa`.`assignment_id` = `a`.`id`)))
where ((`p`.`classroom_id` = 'classroom_id') and (`p`.`student_id` = 'student_id'));

