create
    definer = root@`%` procedure EditDepartmentName(IN department_id varchar(50), IN new_department_name varchar(255))
BEGIN
    UPDATE department
    SET name = new_department_name
    WHERE id = department_id;
END;

