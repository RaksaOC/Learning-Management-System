create definer = root@`%` view view_classroom_id as
select `LMS2`.`classroom`.`id` AS `id`
from `LMS2`.`classroom`
order by `LMS2`.`classroom`.`id`;

