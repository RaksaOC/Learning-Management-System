create
    definer = root@`%` procedure EditStudentAddress(IN student_id varchar(50), IN new_commune varchar(255),
                                                    IN new_district varchar(255), IN new_province varchar(255))
BEGIN
    UPDATE student
    SET commune  = new_commune,
        district = new_district,
        province = new_province
    WHERE id = student_id;
END;

