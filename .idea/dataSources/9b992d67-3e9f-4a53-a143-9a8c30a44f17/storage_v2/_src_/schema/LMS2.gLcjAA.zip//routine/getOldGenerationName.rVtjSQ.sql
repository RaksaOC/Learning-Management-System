create
    definer = root@`%` function getOldGenerationName(idToEdit varchar(255)) returns varchar(255) deterministic
BEGIN
    DECLARE generation_name VARCHAR(255);

    SELECT name INTO generation_name
    FROM generation
    WHERE id = idToEdit;

    RETURN generation_name;
END;

