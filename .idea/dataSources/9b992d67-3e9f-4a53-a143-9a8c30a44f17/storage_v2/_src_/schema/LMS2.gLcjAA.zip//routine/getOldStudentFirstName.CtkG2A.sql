create
    definer = root@`%` function getOldStudentFirstName(idToEdit varchar(255)) returns varchar(255) deterministic
BEGIN
    DECLARE result VARCHAR(255);
    SELECT first_name INTO result FROM student WHERE id = idToEdit;
    RETURN result;
END;

