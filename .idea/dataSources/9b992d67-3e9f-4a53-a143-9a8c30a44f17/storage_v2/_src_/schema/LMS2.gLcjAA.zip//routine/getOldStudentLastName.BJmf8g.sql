create
    definer = root@`%` function getOldStudentLastName(idToEdit varchar(255)) returns varchar(255) deterministic
BEGIN
    DECLARE result VARCHAR(255);
    SELECT last_name INTO result FROM student WHERE id = idToEdit;
    RETURN result;
END;

