create
    definer = root@`%` procedure DeleteMaterial(IN p_material_id varchar(50))
BEGIN
    UPDATE material
    SET status = 'inactive'
    WHERE id = p_material_id;

    DELETE FROM classroom_material cm
    WHERE cm.material_id = p_material_id;

    DELETE FROM progress_material pm
    WHERE pm.material_id = p_material_id;
END;

