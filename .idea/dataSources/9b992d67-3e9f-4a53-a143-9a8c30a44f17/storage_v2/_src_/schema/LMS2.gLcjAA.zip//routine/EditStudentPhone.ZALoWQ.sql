create
    definer = root@`%` procedure EditStudentPhone(IN student_id varchar(50), IN new_phone_number varchar(50))
BEGIN
    UPDATE student
    SET phone_number = new_phone_number
    WHERE id = student_id;
END;

