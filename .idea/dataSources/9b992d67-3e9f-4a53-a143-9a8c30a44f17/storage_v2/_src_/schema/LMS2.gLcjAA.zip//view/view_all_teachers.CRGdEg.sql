create definer = root@`%` view view_all_teachers as
select `LMS2`.`teacher`.`id`           AS `id`,
       `LMS2`.`teacher`.`first_name`   AS `first_name`,
       `LMS2`.`teacher`.`last_name`    AS `last_name`,
       `LMS2`.`teacher`.`gender`       AS `gender`,
       `LMS2`.`teacher`.`dob`          AS `dob`,
       `LMS2`.`teacher`.`phone_number` AS `phone_number`,
       `LMS2`.`teacher`.`email`        AS `email`,
       `LMS2`.`teacher`.`status`       AS `status`,
       `LMS2`.`teacher`.`created_at`   AS `created_at`,
       `LMS2`.`teacher`.`last_login`   AS `last_login`
from `LMS2`.`teacher`;

