create
    definer = root@`%` procedure EditAdminGender(IN admin_id varchar(50), IN new_gender varchar(50))
BEGIN
    UPDATE admin
    SET gender = new_gender
    WHERE id = admin_id;
END;

