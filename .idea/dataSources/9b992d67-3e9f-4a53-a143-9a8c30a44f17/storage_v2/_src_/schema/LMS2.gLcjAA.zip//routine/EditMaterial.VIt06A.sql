create
    definer = root@`%` procedure EditMaterial(IN p_newTitle varchar(255), IN p_newDescription text,
                                              IN p_ref_attachment varchar(255), IN p_material_id varchar(50))
BEGIN
    -- Update material table with new details
    UPDATE material
    SET title = p_newTitle,
        description = p_newDescription,
        ref_attachment = p_ref_attachment
    WHERE id = p_material_id;
END;

