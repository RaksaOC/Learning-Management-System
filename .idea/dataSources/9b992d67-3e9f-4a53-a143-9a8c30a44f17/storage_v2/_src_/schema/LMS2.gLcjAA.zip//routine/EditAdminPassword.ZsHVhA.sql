create
    definer = root@`%` procedure EditAdminPassword(IN admin_id varchar(50), IN new_password varchar(255))
BEGIN
    UPDATE admin
    SET password = new_password
    WHERE id = admin_id;
END;

