create
    definer = root@`%` procedure EditGroupId(IN old_group_id varchar(50), IN new_group_id varchar(50))
BEGIN
    UPDATE student_group
    SET id = new_group_id
    WHERE id = old_group_id;
END;

