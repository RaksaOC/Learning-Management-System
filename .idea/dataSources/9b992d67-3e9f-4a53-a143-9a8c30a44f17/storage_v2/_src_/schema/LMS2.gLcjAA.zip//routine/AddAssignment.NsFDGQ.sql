create
    definer = root@`%` procedure AddAssignment(IN p_id varchar(50), IN p_title varchar(255), IN p_description text,
                                               IN p_deadline date, IN p_ref_attachment varchar(255),
                                               IN p_classroom_id varchar(50))
BEGIN
    -- Insert into Assignment table
    INSERT INTO assignment (id, title, description, deadline, status, ref_attachment)
    VALUES (p_id, p_title, p_description, p_deadline, 'active', p_ref_attachment);

    -- Insert into Classroom_Assignment table
    INSERT INTO classroom_assignment (class_id, assignment_id)
    VALUES (p_classroom_id, p_id);

    -- Insert into Progress_Assignment table
    INSERT INTO progress_assignment (progress_id, assignment_id, score, sub_attachment, status)
    SELECT id, p_id, NULL, NULL, 'active'
    FROM progress WHERE classroom_id = p_classroom_id;
END;

