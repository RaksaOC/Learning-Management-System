create
    definer = root@`%` function getOldDob(idToEdit varchar(255)) returns date deterministic
BEGIN
    DECLARE dob DATE;

    SELECT dob INTO dob
    FROM admin
    WHERE id = idToEdit;

    RETURN dob;
END;

