create
    definer = root@`%` procedure AddMaterial(IN p_id varchar(50), IN p_title varchar(255), IN p_description text,
                                             IN p_ref_attachment varchar(255), IN p_classroom_id varchar(50))
BEGIN
    -- Insert into material table
    INSERT INTO material (id, title, description, status, ref_attachment)
    VALUES (p_id, p_title, p_description, 'active', p_ref_attachment);

    -- Insert into classroom_material (associating material with a classroom)
    INSERT INTO classroom_material (class_id, material_id)
    VALUES (p_classroom_id, p_id);

    -- Insert into progress_material for students in the selected classroom
    INSERT INTO progress_material (progress_id, material_id, status)
    SELECT id, p_id, 'active'
    FROM progress
    WHERE classroom_id = p_classroom_id;
END;

