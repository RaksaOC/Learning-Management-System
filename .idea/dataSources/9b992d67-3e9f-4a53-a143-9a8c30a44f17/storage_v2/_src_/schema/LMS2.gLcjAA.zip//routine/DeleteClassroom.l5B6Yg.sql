create
    definer = root@`%` procedure DeleteClassroom(IN p_id varchar(255))
BEGIN
    UPDATE classroom
    SET status = 'inactive'
    WHERE id = p_id;
END;

