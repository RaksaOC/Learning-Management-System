create
    definer = root@`%` procedure EditTeacherPhone(IN teacher_id varchar(50), IN new_phone_number varchar(50))
BEGIN
    UPDATE teacher
    SET phone_number = new_phone_number
    WHERE id = teacher_id;
END;

