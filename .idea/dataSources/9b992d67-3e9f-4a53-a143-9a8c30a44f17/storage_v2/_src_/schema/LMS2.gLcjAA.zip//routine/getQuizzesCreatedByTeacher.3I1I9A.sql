create
    definer = root@`%` function getQuizzesCreatedByTeacher(teacher_id int) returns int deterministic
BEGIN
    DECLARE created_quizzes INT;

    -- Count the number of quizzes created by the teacher
    SELECT COUNT(*)
    INTO created_quizzes
    FROM classroom_quiz cq
             JOIN classroom c ON cq.class_id = c.id
    WHERE c.teacher_id = teacher_id;

    RETURN created_quizzes;
END;

