create
    definer = root@`%` function getTotalTeachers() returns int deterministic
BEGIN
    DECLARE teacher_count INT;

    -- Count the total number of teachers
    SELECT COUNT(*)
    INTO teacher_count
    FROM teacher;

    RETURN teacher_count;
END;

