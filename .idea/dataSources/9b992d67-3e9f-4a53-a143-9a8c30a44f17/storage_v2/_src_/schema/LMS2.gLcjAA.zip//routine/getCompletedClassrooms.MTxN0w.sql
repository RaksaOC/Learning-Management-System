create
    definer = root@`%` function getCompletedClassrooms(student_id int) returns int deterministic
BEGIN
    DECLARE completed_classrooms INT;

    -- Count the number of classrooms that the student has completed (inactive status)
    SELECT COUNT(*)
    INTO completed_classrooms
    FROM progress p
             JOIN classroom c ON p.classroom_id = c.id
    WHERE p.student_id = student_id AND c.status = 'inactive';

    RETURN completed_classrooms;
END;

