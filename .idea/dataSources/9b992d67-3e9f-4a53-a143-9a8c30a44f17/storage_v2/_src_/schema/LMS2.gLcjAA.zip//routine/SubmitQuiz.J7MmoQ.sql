create
    definer = root@`%` procedure SubmitQuiz(IN p_student_id varchar(50), IN p_quiz_id varchar(50),
                                            IN p_score decimal(5, 2))
BEGIN
    UPDATE progress_quiz pq
        JOIN progress p ON pq.progress_id = p.id
    SET pq.score = p_score
    WHERE pq.quiz_id = p_quiz_id AND p.student_id = p_student_id;
END;

