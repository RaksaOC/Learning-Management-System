create
    definer = root@`%` procedure GradeAssignment(IN p_score decimal(5, 2), IN p_student_id varchar(50),
                                                 IN p_classroom_id varchar(50), IN p_assignment_id varchar(50))
BEGIN
    DECLARE p_progress_id VARCHAR(50);

    -- Get student's progress id
    SELECT p.id
    INTO p_progress_id
    FROM progress p
    WHERE p.student_id = p_student_id AND p.classroom_id = p_classroom_id;

    -- Update the grade for the assignment
    UPDATE progress_assignment
    SET score = p_score, status = 'inactive'
    WHERE progress_id = p_progress_id AND assignment_id = p_assignment_id;
END;

