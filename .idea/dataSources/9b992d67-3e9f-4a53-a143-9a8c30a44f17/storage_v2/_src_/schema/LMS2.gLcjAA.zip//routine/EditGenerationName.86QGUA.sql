create
    definer = root@`%` procedure EditGenerationName(IN generation_id varchar(50), IN new_generation_name varchar(255))
BEGIN
    UPDATE generation
    SET name = new_generation_name
    WHERE id = generation_id;
END;

