create definer = root@`%` view view_course_ids_and_names as
select `LMS2`.`course`.`id` AS `id`, `LMS2`.`course`.`name` AS `name`
from `LMS2`.`course`
order by `LMS2`.`course`.`name`;

