create definer = root@`%` view view_all_classrooms as
select `LMS2`.`classroom`.`id`         AS `id`,
       `LMS2`.`classroom`.`teacher_id` AS `teacher_id`,
       `LMS2`.`classroom`.`course_id`  AS `course_id`,
       `LMS2`.`classroom`.`group_id`   AS `group_id`,
       `LMS2`.`classroom`.`status`     AS `status`
from `LMS2`.`classroom`;

