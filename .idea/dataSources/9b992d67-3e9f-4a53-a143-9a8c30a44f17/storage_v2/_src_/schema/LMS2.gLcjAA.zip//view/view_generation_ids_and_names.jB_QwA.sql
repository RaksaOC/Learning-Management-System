create definer = root@`%` view view_generation_ids_and_names as
select `LMS2`.`generation`.`id` AS `id`, `LMS2`.`generation`.`name` AS `name`
from `LMS2`.`generation`
order by `LMS2`.`generation`.`name`;

