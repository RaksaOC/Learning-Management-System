create definer = root@`%` view student_all_quizzes as
select concat(`q`.`id`, ' - ', `q`.`title`) AS `quiz_id_name`, `p`.`classroom_id` AS `class_id`
from ((`LMS2`.`progress_quiz` `pq` join `LMS2`.`progress` `p`
       on ((`pq`.`progress_id` = `p`.`id`))) join `LMS2`.`quiz` `q` on ((`pq`.`quiz_id` = `q`.`id`)))
where (`p`.`student_id` = 'student_id');

