create
    definer = root@`%` procedure EditStudentGuardian(IN student_id varchar(50), IN new_guardian_first_name varchar(255),
                                                     IN new_guardian_last_name varchar(255),
                                                     IN new_guardian_gender varchar(10),
                                                     IN new_guardian_phone_number varchar(50))
BEGIN
    UPDATE student
    SET guardian_first_name   = new_guardian_first_name,
        guardian_last_name    = new_guardian_last_name,
        guardian_gender       = new_guardian_gender,
        guardian_phone_number = new_guardian_phone_number
    WHERE id = student_id;
END;

